# Exploratory Data Analysis: Palmer Penguins

**Goal:** Identify the patterns, correlations and key factors that drive penguin body measurements.
**Tools:** Python, Pandas, SciPy, Matplotlib, Seaborn
**Code:** `eda_penguins.py`, with all raw numbers in `eda_stats.txt`

---

## 1. Dataset overview

| Item | Value |
|---|---|
| Rows / columns (raw) | 344 / 7 |
| Species | Adelie (151), Gentoo (123), Chinstrap (68) |
| Islands | Biscoe (167), Dream (124), Torgersen (51) |
| Numeric features | bill length, bill depth, flipper length, body mass |
| Categorical features | species, island, sex |

## 2. Data quality and cleaning

- **Duplicates:** none.
- **Missing values:** 2 rows had *all four* measurements missing, so they carry no information and were dropped (344 → 342). A further 9 rows were missing only `sex`; they were kept and labelled "Unknown" so they still count in all non-sex analyses.
- **Outliers:** the IQR rule flagged **0** outliers in all four measurements. Nothing was capped or removed.
- **Distributions:** all four measurements are close to symmetric (skewness between −0.14 and 0.47), so mean-based statistics are reasonable.

## 3. Summary statistics

| Feature | Mean | Std | Min | Max |
|---|---|---|---|---|
| Bill length (mm) | 43.9 | 5.5 | 32.1 | 59.6 |
| Bill depth (mm) | 17.2 | 2.0 | 13.1 | 21.5 |
| Flipper length (mm) | 200.9 | 14.1 | 172 | 231 |
| Body mass (g) | 4201.8 | 802.0 | 2700 | 6300 |

Mean by species:

| Species | Bill length | Bill depth | Flipper | Body mass |
|---|---|---|---|---|
| Adelie | 38.8 | 18.3 | 190.0 | 3700.7 |
| Chinstrap | 48.8 | 18.4 | 195.8 | 3733.1 |
| Gentoo | 47.5 | 15.0 | 217.2 | 5076.0 |

![Overview](fig1_overview.png)

## 4. Key findings

### Finding 1: Species is the strongest driver of body size
Species alone explains **67%** of the variance in body mass. All four measurements differ significantly across species (Kruskal-Wallis, p < 1e-47 for each). Gentoo penguins are about 1.4 kg heavier than the other two species and have much longer flippers (217 mm vs 190-196 mm). Adelie and Chinstrap have almost the same body mass (3.70 kg vs 3.73 kg) but very different bills: Chinstrap bills are about 10 mm longer.

### Finding 2: Flipper length is the best single predictor of body mass
Flipper length and body mass correlate at **r = 0.87** (R² = 0.76). Within each species the relationship stays positive but is weaker (r = 0.47 to 0.70), because part of the overall correlation comes from the species differences.

![Relationships](fig2_relationships.png)

### Finding 3: Simpson's paradox in bill dimensions
Across the whole dataset, bill length and bill depth are **negatively** correlated (r = −0.24), which would suggest that longer bills are shallower. This is misleading. **Within every species the correlation is positive** (Adelie 0.39, Chinstrap 0.65, Gentoo 0.64). The overall negative trend appears only because Gentoo have long but shallow bills and Adelie have short but deep ones. Ignoring the species grouping would give the opposite conclusion.

### Finding 4: Males are consistently larger
Males exceed females on every measurement (Welch t-test, all p < 1e-5). The largest effect is body mass: about **683 g heavier** (Cohen's d = 0.94, a large effect). Effects for bill length (d = 0.73), bill depth (d = 0.80) and flipper length (d = 0.53) are medium to large. The violin plot shows the same gap within each species.

![Simpson's paradox and dimorphism](fig3_simpson_and_dimorphism.png)

### Finding 5: Island is mostly a proxy for species
Island explains 39% of body mass variance, but this is largely confounded with species: Torgersen holds only Adelie, Biscoe is mostly Gentoo, and only Dream mixes two species (Adelie and Chinstrap). Island should not be treated as an independent cause.

## 5. Ranking of influencing factors (for body mass)

| Factor | Variance explained (R²) |
|---|---|
| Flipper length (linear) | 0.76 |
| Species | 0.67 |
| Island | 0.39 (confounded with species) |
| Sex | 0.18 |

## 6. Limitations

- These are observational data from a limited number of sites; correlations do not imply causation.
- 9 individuals have unknown sex; sex-specific results use the remaining 333.
- The R² values are single-factor figures and overlap, so they do not add up. A multivariable model (for example species + sex + flipper length together) would show their joint effect.
- Statistical significance is very high because of the group differences, so the effect sizes (Cohen's d) are the more informative numbers.

## 7. Conclusions and next steps

1. Always analyse by species. Pooled statistics hide the true relationships (Simpson's paradox).
2. Body size is best explained by species and flipper length, with sex adding a consistent secondary effect.
3. Next step: fit a regression or random forest on species + sex + flipper length to quantify their joint explanatory power, or build a species classifier from bill and flipper measurements.
