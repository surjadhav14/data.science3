"""
Exploratory Data Analysis - Palmer Penguins
Usage: python eda_penguins.py [penguins.csv]
Outputs: fig1_overview.png, fig2_relationships.png, fig3_simpson_and_dimorphism.png, eda_stats.txt
"""
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

PATH = sys.argv[1] if len(sys.argv) > 1 else "penguins.csv"
sns.set_theme(style="whitegrid", palette="deep")
out = []
def log(m=""):
    print(m); out.append(str(m))

df = pd.read_csv(PATH)
num = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]

# ---------------------------------------------------------------- 1. STRUCTURE & QUALITY
log("=== 1. STRUCTURE & DATA QUALITY ===")
log(f"shape: {df.shape} | duplicates: {df.duplicated().sum()}")
log("missing values:\n" + df.isna().sum()[df.isna().sum() > 0].to_string())
rows_all_missing = df[num].isna().all(axis=1).sum()
log(f"rows with ALL measurements missing: {rows_all_missing} (uninformative -> dropped)")
df = df.dropna(subset=num).copy()
log(f"sex missing after that: {df.sex.isna().sum()} (kept as 'Unknown' for non-sex analyses)")
df["sex"] = df["sex"].str.title()
df["sex_f"] = df["sex"].fillna("Unknown")
df.to_csv("penguins_clean.csv", index=False)
log(f"clean shape: {df.shape}")

# ---------------------------------------------------------------- 2. SUMMARY STATS
log("\n=== 2. SUMMARY STATISTICS ===")
log(df[num].describe().round(2).to_string())
log("\nskewness:\n" + df[num].skew().round(2).to_string())
log("\ncategory counts:")
for c in ["species", "island", "sex_f"]:
    log(df[c].value_counts().to_string() + "\n")
log("island x species:\n" + pd.crosstab(df.island, df.species).to_string())
log("\nmean by species:\n" + df.groupby("species")[num].mean().round(1).to_string())

# outliers (IQR) - reported, NOT removed (they are real measurements)
log("\nIQR outlier counts (kept):")
for c in num:
    q1, q3 = df[c].quantile([.25, .75]); i = q3 - q1
    log(f"  {c}: {((df[c] < q1 - 1.5*i) | (df[c] > q3 + 1.5*i)).sum()}")

# ---------------------------------------------------------------- 3. HYPOTHESIS TESTS
log("\n=== 3. STATISTICAL TESTS ===")
for c in num:
    groups = [g[c].values for _, g in df.groupby("species")]
    h, p = stats.kruskal(*groups)
    log(f"Kruskal-Wallis {c} ~ species: H={h:.1f}, p={p:.2e}")
known = df.dropna(subset=["sex"])
for c in num:
    m, f = known[known.sex == "Male"][c], known[known.sex == "Female"][c]
    t, p = stats.ttest_ind(m, f, equal_var=False)
    d = (m.mean() - f.mean()) / np.sqrt((m.var() + f.var()) / 2)
    log(f"Welch t-test {c} male vs female: diff={m.mean()-f.mean():.1f}, Cohen d={d:.2f}, p={p:.2e}")

# ---------------------------------------------------------------- 4. CORRELATIONS & SIMPSON'S PARADOX
log("\n=== 4. CORRELATIONS ===")
corr = df[num].corr()
log("overall Pearson:\n" + corr.round(2).to_string())
log("\nbill_length vs bill_depth: overall vs within-species")
r_all = df.bill_length_mm.corr(df.bill_depth_mm)
log(f"  overall r = {r_all:.2f}")
for s, g in df.groupby("species"):
    log(f"  {s}: r = {g.bill_length_mm.corr(g.bill_depth_mm):.2f}")
log("\nflipper_length vs body_mass: overall vs within-species")
log(f"  overall r = {df.flipper_length_mm.corr(df.body_mass_g):.2f}")
for s, g in df.groupby("species"):
    log(f"  {s}: r = {g.flipper_length_mm.corr(g.body_mass_g):.2f}")

# What explains body mass? simple variance decomposition (eta^2 / R^2)
log("\nVariance in body_mass explained by (R^2):")
for col in ["species", "island", "sex"]:
    d_ = df.dropna(subset=[col])
    ss_b = sum(len(g) * (g.body_mass_g.mean() - d_.body_mass_g.mean())**2 for _, g in d_.groupby(col))
    ss_t = ((d_.body_mass_g - d_.body_mass_g.mean())**2).sum()
    log(f"  {col}: {ss_b/ss_t:.2f}")
r2_fl = df.flipper_length_mm.corr(df.body_mass_g)**2
log(f"  flipper_length (linear): {r2_fl:.2f}")

# ---------------------------------------------------------------- 5. FIGURES
# Fig 1 overview
fig, ax = plt.subplots(2, 3, figsize=(17, 9))
fig.suptitle("Fig 1 - Overview: distributions, composition, missingness", fontsize=18, fontweight="bold")
for a, c in zip(ax.flat[:4], num):
    sns.histplot(df, x=c, hue="species", multiple="stack", bins=25, ax=a)
    a.set_title(f"{c} by species")
ct = pd.crosstab(df.island, df.species)
ct.plot.bar(stacked=True, ax=ax[1, 1], rot=0); ax[1, 1].set_title("Species composition per island")
sns.countplot(data=df, x="sex_f", hue="species", ax=ax[1, 2]); ax[1, 2].set_title("Sex balance (Unknown = missing)")
plt.tight_layout(); plt.savefig("fig1_overview.png", dpi=140); plt.close()

# Fig 2 relationships
fig, ax = plt.subplots(1, 3, figsize=(18, 5.5))
fig.suptitle("Fig 2 - Group differences and correlations", fontsize=18, fontweight="bold")
sns.boxplot(data=df, x="species", y="body_mass_g", hue="species", ax=ax[0], legend=False)
sns.stripplot(data=df, x="species", y="body_mass_g", color="k", alpha=.3, size=3, ax=ax[0])
ax[0].set_title("Body mass by species")
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax[1], cbar=False)
ax[1].set_title("Overall correlation matrix"); ax[1].tick_params(axis="x", rotation=30)
sns.scatterplot(data=df, x="flipper_length_mm", y="body_mass_g", hue="species", style="sex_f", ax=ax[2])
ax[2].set_title("Flipper length vs body mass")
plt.tight_layout(); plt.savefig("fig2_relationships.png", dpi=140); plt.close()

# Fig 3 Simpson + dimorphism
fig, ax = plt.subplots(1, 3, figsize=(18, 5.5))
fig.suptitle("Fig 3 - Simpson's paradox and sexual dimorphism", fontsize=18, fontweight="bold")
sns.regplot(data=df, x="bill_length_mm", y="bill_depth_mm", scatter=False, color="k", ax=ax[0],
            line_kws={"ls": "--"})
sns.scatterplot(data=df, x="bill_length_mm", y="bill_depth_mm", hue="species", ax=ax[0])
ax[0].set_title(f"Overall trend r={r_all:.2f} (dashed)")
for s, g in df.groupby("species"):
    sns.regplot(data=g, x="bill_length_mm", y="bill_depth_mm", scatter=False, ax=ax[1], label=s)
sns.scatterplot(data=df, x="bill_length_mm", y="bill_depth_mm", hue="species", alpha=.4, ax=ax[1], legend=False)
ax[1].set_title("Within-species trends (all positive)"); ax[1].legend()
sns.violinplot(data=known, x="species", y="body_mass_g", hue="sex", split=True, inner="quart", ax=ax[2])
ax[2].set_title("Body mass: males vs females")
plt.tight_layout(); plt.savefig("fig3_simpson_and_dimorphism.png", dpi=140); plt.close()

open("eda_stats.txt", "w").write("\n".join(out))
